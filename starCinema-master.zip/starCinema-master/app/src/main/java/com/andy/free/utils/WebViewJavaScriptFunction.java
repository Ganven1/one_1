package com.andy.free.utils;

/**
 * Created by Administrator on 2017/10/14.
 */

public interface WebViewJavaScriptFunction {
    void onJsFunctionCalled(String tag);
}
