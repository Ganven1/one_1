package com.andy.free.utils;

import android.support.annotation.NonNull;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

/**
 * Created by Administrator on 2017/10/20.
 */

public class ConstantUtil {

    public static final String BASE_URL="http://api.baiyug.cn/vip/index.php?url=";
    public static final String MOVIE_BASE_2345_URL="http://dianying.2345.com/list/";

}

