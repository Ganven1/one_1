#功能介绍
    1.全网VIP视频免广告播放
    2.全网电视剧免广告播放
    3.视频互动直播，支持打赏
    4.支持视频地址输入直接播放

#待完善功能
    1.登录/注册功能
    2.视频播放历史记录功能
    3.其他更多...

#开源第三方库
<code></code>
`   compile 'com.android.support:appcompat-v7:25.3.1'
     compile 'com.android.support:design:25.3.1'
     testCompile 'junit:junit:4.12'
     compile 'com.android.support:percent:25.3.1'
     compile 'com.android.support:cardview-v7:25.3.1'
     compile 'com.android.support:recyclerview-v7:25.3.1'
     /*一个炫酷的RecyclerView*/
     compile 'com.github.Aspsine:IRecyclerView:0.0.5'
     //视图绑定 butterknife
     compile 'com.jakewharton:butterknife:8.4.0'
     apt 'com.jakewharton:butterknife-compiler:8.4.0'
     //漂亮的弹框
     compile 'cn.pedant.sweetalert:library:1.3'
     //jsoup解析html
     compile 'org.jsoup:jsoup:1.9.2'
     //自动轮播
     compile 'com.youth.banner:banner:1.4.9'
     //图片加载
     compile 'com.github.bumptech.glide:glide:3.7.0'
     //FlycoTabLayout
     compile 'com.flyco.tablayout:FlycoTabLayout_Lib:2.1.2@aar'
     compile files('libs/tbs_sdk_thirdapp_v3.5.0.1004_43500_sharewithdownload_withoutGame_obfs_20170801_113025.jar')`

#声明

该作品属于个人开发作品，仅做学习交流使用。诸位勿传播于非技术人员，拒绝用于商业用途，数据均属于非正常渠道获取，原作公司拥有所有权利。
